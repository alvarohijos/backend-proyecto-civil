package com.proyecto.constructora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConstructoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConstructoraApplication.class, args);
	}

}
